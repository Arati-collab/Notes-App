"use client";

import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "@/lib/firebase";

export default function Home() {

  const login = async () => {
    await signInWithPopup(auth, provider);
  };

  return (
    <main className="flex min-h-screen items-center justify-center">
      <button
        onClick={login}
        className="bg-black text-white px-4 py-2 rounded"
      >
        Login with Google
      </button>
    </main>
  );
}